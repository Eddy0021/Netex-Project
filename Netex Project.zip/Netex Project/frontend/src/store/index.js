import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    users: [],
    displayUsers: [],
    rows: 0,
    showSpinner: false
  },
  getters: {
    users(state){
      return state.users;
    },
    rows(state) {
      return state.rows;
    },
    displayUsers(state){
      return state.displayUsers;
    },
    showSpinner(state) {
      return state.showSpinner;
    }
  },
  mutations: {
    SET_USERS(state, users){
      state.users = users;
    },
    SET_ROWS(state, rows){
      state.rows = rows;
    },
    SET_DISPLAY_USERS(state, displayUsers){
      state.displayUsers = displayUsers;
    },
    SET_SPINNER(state, showSpinner){
      state.showSpinner = showSpinner;
    },
  },
  actions: {
    async fetchData({commit}){
      commit("SET_SPINNER", true);
      return new Promise(resolve => {
        setTimeout(async () => {
          const res = await fetch("http://localhost:8080/api/v1/user")
          const val = await res.json();
          resolve(val);
          commit("SET_SPINNER", false);
        }, 1000)
      })
    },
    async fetchUsers({dispatch, commit}){
      const myJson = await dispatch("fetchData");  
      commit("SET_USERS", myJson);
      commit("SET_ROWS", myJson.length);
      const displayUsers = myJson.slice(0, 3);
      commit("SET_DISPLAY_USERS", displayUsers);
      commit("SET_ROWS", myJson.length);
    },
    async paginate({ commit, state }, {currentPage, perPage}){
      const start = (currentPage - 1) * perPage;
      const users = state.users.slice(start, start + 3);
      commit("SET_DISPLAY_USERS", users);
    },
    updatePagination({commit,dispatch}, {myJson, currentPage, perPage}){
      commit("SET_USERS", myJson);
      commit("SET_ROWS", myJson.length);
      dispatch("paginate", {currentPage, perPage});
    },
    async search({dispatch}, {text}){
      const myJson = await dispatch("fetchData");
      const value = myJson.filter(val => val.name.toLowerCase().includes(text.toLowerCase()));
      dispatch("updatePagination", {myJson: value, currentPage: 1, perPage: 3})
    }
  },
  modules: {
  }
})
