<template>
  <b-container>
    <b-row class="addUser">
      <b-button v-b-modal.addUser variant="dark text-right">+</b-button>
      <b-modal id="addUser" title="Upload user" @ok="handleOk">
            <form ref="form" @submit.stop.prevent="handleSubmit">
              <b-form-group
                label="img"
                label-for="img-input"
                invalid-feedback="Image is required"
              >
                <b-form-file
                v-model="myfile"
                :state="imageState"
                placeholder="Choose a image or drop it here..."
                drop-placeholder="Drop image here..."
                required
              ></b-form-file>
              </b-form-group>

              <b-form-group
                label="Name"
                label-for="name-input"
                invalid-feedback="Name is required"
              >
                <b-form-input
                  id="name-input"
                  v-model="name"
                  :state="nameState"
                  required
                ></b-form-input>
              </b-form-group>

                <b-form-group
                label="Address"
                label-for="address-input"
                invalid-feedback="Address is required"
              >
                <b-form-input
                  id="address-input"
                  v-model="address"
                  :state="addressState"
                  required
                ></b-form-input>
              </b-form-group>
            </form>
      </b-modal>
    </b-row>
    <b-row align-v="center" class="rowclass">
      <user-card
        v-for="user in displayUsers"
        :key="user.id"
        :name="user.name"
        :address="user.address"
        :id="user.id"
        :img_url="user.img_url"
        :img_name="user.img_name"
      ></user-card>
    </b-row>
    <b-pagination
      v-model="currentPage"
      :total-rows="rows"
      :per-page="perPage"
      first-text="First"
      prev-text="Prev"
      next-text="Next"
      last-text="Last"
      @input="paginate(currentPage)"
    ></b-pagination>

    <b-button @click="downloadCSV()" variant="dark text-right">CSV</b-button>
  </b-container>
</template>

<script>
import UserCard from "@/components/UserCard.vue";
import axios from 'axios';
import {mapGetters} from "vuex";

export default {
  name: "home-",
  components: { "user-card": UserCard },
  computed: {
    ...mapGetters(["users", "displayUsers", "rows"])
  },
  data() {
    return {
      currentPage: 1,
      perPage: 3,
      myfile: [],
      name: "",
      address: "",

      imageState: null,
      nameState: null,
      addressState: null,
    };
  },
  methods: {
    async loadUsers() {
      await this.$store.dispatch("fetchUsers");    
    },
    paginate(currentPage) {
      this.$store.dispatch("paginate", {currentPage, perPage: this.perPage})
    },

    checkFormValidity() {
        const valid = this.$refs.form.checkValidity()

        this.imageState = valid
        this.nameState = valid
        this.addressState = valid
        
        return valid
    },

    resetModal() {
        this.myfile = ''
        this.name = ''
        this.address = ''

        this.imageState = null
        this.nameState = null
        this.addressState = null
    },

    handleOk(bvModalEvt) {
        // Prevent modal from closing
        bvModalEvt.preventDefault()
        // Trigger submit handler
        this.handleSubmit()
      },

    handleSubmit(){

      // Exit when the form isn't valid
      if (!this.checkFormValidity()) {
        return
      }

      var formData = new FormData();
      formData.append("file", this.myfile);
      formData.append("name", this.name)
      formData.append("address", this.address)
      try {
        axios.post("http://localhost:8080/api/v1/user/", formData)
          .then((response) => {
            console.log(response);
          })
      } catch (error) {
        if (error.response) alert(error.response.data);
      }
      this.loadUsers();

    },

    downloadCSV(){
      
      //define the heading for each row of the data
      var csv = 'id,name,address,img_name,img_url\n';

      var obj = JSON.parse(JSON.stringify(this.users));
      var res = [];      
      
      obj.forEach(element => {
        console.log("element: "+element.csv);
      });

      //merge the data with CSV
      res.forEach(function(row) {
              csv += row.join(',');
              csv += "\n";
      });
  
      //display the created CSV data on the web browser 
      document.write(csv);

    
      var hiddenElement = document.createElement('a');
      hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
      hiddenElement.target = '_blank';
      
      //provide the name for the CSV file to be downloaded
      hiddenElement.download = 'Famous Personalities.csv';
      hiddenElement.click();
      }
    },

  mounted() {
    this.loadUsers();
  },
};
</script>

<style>
.container {
  margin-top: 5rem;
}

.pagination {
  justify-content: center;
  margin-top: 2rem;
}

.row {
  justify-content: center;
}

.addUser {
    width: 100%;
    display: flex;
    justify-content: end;
}
</style>
