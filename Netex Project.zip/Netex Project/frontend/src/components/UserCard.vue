<template>
  <div>
    <b-col>
      <b-card
        :title="name"
        :img-src="`http://localhost:8080/`+ img_url"
        img-alt="Alt info"
        img-top
        tag="article"
        style="max-width: 20rem"
        class="mb"
      >
        <b-card-text> {{ address }} </b-card-text>

        <b-btn-toolbar justify>
          <b-button v-b-modal="modalId" variant="primary">Edit</b-button>
          <b-modal :id="modalId" title="Edit user" @ok="handleOk">
            <form ref="form" @submit.stop.prevent="handleSubmit">
              <b-form-group
                label="img"
                label-for="img-input"
                invalid-feedback="Image is required"
              >
                <b-form-file
                v-model="myNewfiles"
                :state="imageState"
                :placeholder="modalImgName"
                drop-placeholder="Drop image here..."
                required
              ></b-form-file>
              </b-form-group>

              <b-form-group
                label="Name"
                label-for="name-input"
                invalid-feedback="Name is required"
              >
                <b-form-input
                  id="name-input"
                  v-model="newName"
                  :state="nameState"
                  :placeholder="modalName"
                  required
                ></b-form-input>
              </b-form-group>

                <b-form-group
                label="Address"
                label-for="address-input"
                invalid-feedback="Address is required"
              >
                <b-form-input
                  id="address-input"
                  v-model="newAddress"
                  :placeholder="modalAddress"
                  :state="addressState"
                  required
                ></b-form-input>
              </b-form-group>
            </form>
          </b-modal>


          <b-button variant="primary" @click="deleteUser(id)">Delete</b-button>
        </b-btn-toolbar>
      </b-card>
    </b-col>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  /* eslint-disable */
  data(){
    return{
      myNewfiles: [],
      newName: "",
      newAddress: "",
      imageState: null,
      nameState: null,
      addressState: null
    };
  },
  props: ["name", "address", "id", "img_url", "img_name"],
  computed: {
    modalId(){
      return `modal-${this.id}`;
    },
    modalName(){
      return this.name;
    },
    modalAddress(){
      return this.address;
    },
    modalImgName(){
      return this.img_name;
    }
  },
  methods: {
    async loadUsers() {
      await this.$store.dispatch("fetchUsers");    
    },
    deleteUser(item){
      try {
        axios.delete(`http://localhost:8080/api/v1/user/${item}`)
          .then((response) => {
            console.log(response);
            this.$store.dispatch("fetchUsers"); 
          })
          .catch((error) => {
            if (error.response) {
              alert(error.response.data);
            }
          });
      } catch (error) {
        if (error.response) alert(error.response.data);
      }

      this.loadUsers();

    },

    checkFormValidity() {
        const valid = this.$refs.form.checkValidity()

        this.imageState = valid
        this.nameState = valid
        this.addressState = valid
        
        return valid
    },

    resetModal() {
        this.myfile = ''
        this.name = ''
        this.address = ''

        this.imageState = null
        this.nameState = null
        this.addressState = null
    },

    handleOk(bvModalEvt) {
        // Prevent modal from closing
        bvModalEvt.preventDefault()
        // Trigger submit handler
        this.handleSubmit()
      },

    handleSubmit(){

       if (!this.checkFormValidity()) {
        return
      }


      var formData = new FormData();
      formData.append("id", this.id)
      formData.append("file", this.myNewfiles);
      formData.append("name", this.newName)
      formData.append("address", this.newAddress)

      console.log(formData);
      try {
        axios.put("http://localhost:8080/api/v1/user/", formData)
          .then((response) => {
            console.log(response);
          })
      } catch (error) {
        if (error.response) alert(error.response.data);
      }
      this.loadUsers();
    }
  }
};
</script>

<style>

</style>
