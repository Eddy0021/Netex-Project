package com.example.demo.user;

import javax.persistence.*;

@Entity
public class User {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String address;
    private String img_url;
    private String img_name;

    public User() {
    }

    public User(Integer id, String name, String address, String img_url, String img_name) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.img_url = img_url;
        this.img_name = img_name;
    }

    public User(String name, String address, String img_url, String img_name) {
        this.name = name;
        this.address = address;
        this.img_url = img_url;
        this.img_name = img_name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }

    public String getImg_name() {
        return img_name;
    }

    public void setImg_name(String img_name) {
        this.img_name = img_name;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", img_url='" + img_url + '\'' +
                ", img_name='" + img_name + '\''+
                '}';
    }
}
