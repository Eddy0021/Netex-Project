package com.example.demo.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }


    public List<User> getUsers(){
        return userRepository.findAll();
    }

    public void addNewUser(MultipartFile file, String name, String address) {

        Instant now = Instant.now();

        String img_name = new StringBuilder().append(now.toEpochMilli()).toString();

        String userDirectory = Paths.get("")
                .toAbsolutePath()
                .toString();
        String realPath = (userDirectory + "\\src\\main\\resources\\public");

        File folder = new File(realPath);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        try {
            File image = new File(realPath + "\\" + img_name + ".png");
            if(image.exists()){
                return;
            }
            file.transferTo(new File(folder,img_name + ".png"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        User user = new User();
        user.setImg_name(file.getOriginalFilename());
        user.setImg_url(img_name + ".png");
        user.setName(name);
        user.setAddress(address);

        userRepository.save(user);
    }

    public void deleteUser(Integer userId) {
        boolean exists = userRepository.existsById(userId);

        Optional<User> userRequest = userRepository.findById(userId);

        User user = userRequest.get();

        if(!exists) {
            throw new IllegalStateException("User with id " + userId + " does not exists");
        }

        String userDirectory = Paths.get("")
                .toAbsolutePath()
                .toString();
        String realPath = (userDirectory + "\\src\\main\\resources\\public");

        File folder = new File(realPath);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        try {
            File image = new File(realPath + "\\" + user.getImg_url());
            if(!image.exists()){
                return;
            }
            Path path=Paths.get(realPath + "\\" + user.getImg_url());
            Files.delete(path);
        } catch (IOException e) {
            e.printStackTrace();
        }

        userRepository.deleteById(userId);
    }

    @Transactional
    public void updateUser(MultipartFile file,Integer id , String name, String address) {

        User db_user = userRepository.findById(id).orElseThrow(() -> new IllegalStateException((
                "student with id " + id + " does not exist")));




        if(name != null && name.length() > 0 && !Objects.equals(db_user.getName(), name))
        {
            db_user.setName(name);
        }

        if(address != null && address.length() > 0 && !Objects.equals(db_user.getAddress(), address))
        {
            db_user.setAddress(address);
        }

        if(file.getOriginalFilename() != null && file.getOriginalFilename().length() > 0 && !Objects.equals(db_user.getImg_url(), file.getOriginalFilename()))
        {
            String userDirectory = Paths.get("")
                    .toAbsolutePath()
                    .toString();
            String realPath = (userDirectory + "\\src\\main\\resources\\public");

            Optional<User> userRequest = userRepository.findById(id);

            User user = userRequest.get();

            try {
                File image = new File(realPath + "\\" + user.getImg_url());
                if(!image.exists()){
                    return;
                }
                Path path=Paths.get(realPath + "\\" + user.getImg_url());
                Files.delete(path);
            } catch (IOException e) {
                e.printStackTrace();
            }

            Instant now = Instant.now();

            String img_name = String.valueOf(now.toEpochMilli());

            File folder = new File(realPath);

            try {
                File image = new File(realPath + "\\" + img_name + ".png");
                if(image.exists()){
                    return;
                }
                file.transferTo(new File(folder,img_name + ".png"));
            } catch (IOException e) {
                e.printStackTrace();
            }

            db_user.setImg_url(img_name + ".png");
            db_user.setImg_name(file.getOriginalFilename());
        }
    }
}
