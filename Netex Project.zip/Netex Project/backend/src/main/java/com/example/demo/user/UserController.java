package com.example.demo.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@CrossOrigin(origins = "http://localhost:8081/")
@RestController
@RequestMapping(path = "api/v1/user")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }


    @GetMapping
    public List<User> getUsers(){
        return userService.getUsers();
    }

    @PostMapping
    public void registerNewUser(@RequestParam("file")MultipartFile file, @RequestParam(value = "name") String name, @RequestParam(value = "address") String address){
        userService.addNewUser(file, name, address);
    }

    @DeleteMapping(path = "{userId}")
    public void deleteUser(@PathVariable("userId") Integer userId){
        userService.deleteUser(userId);
    }

    @PutMapping()
    public void updateuser(@RequestParam("file")MultipartFile file,@RequestParam(value = "id") Integer id , @RequestParam(value = "name") String name, @RequestParam(value = "address") String address){
        userService.updateUser(file, id, name, address);
    }
}
